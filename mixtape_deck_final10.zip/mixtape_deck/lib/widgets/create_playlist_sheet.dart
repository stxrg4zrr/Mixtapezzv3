import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../screens/playlist_screen.dart';
import '../theme.dart';

class _NewPlaylist {
  const _NewPlaylist(this.name, this.coverPath);
  final String name;
  final String? coverPath;
}

/// "Create a New Playlist" bottom sheet: title, optional artwork, Create.
/// Without artwork the playlist uses the app icon.
Future<void> showCreatePlaylistSheet(BuildContext context,
    {List<String> thenAdd = const []}) async {
  final store = context.read<LibraryStore>();
  final res = await showModalBottomSheet<_NewPlaylist>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: const Color(0xFF1C1C1E),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (_) => const _CreateSheet(),
  );
  if (res == null) return;

  final pl = await store.createPlaylist(res.name, kPlaylistColorValues.first);
  if (res.coverPath != null) await store.setPlaylistCover(pl, res.coverPath!);

  if (thenAdd.isNotEmpty) {
    await store.addToPlaylist(pl, thenAdd);
    if (context.mounted) {
      final m = ScaffoldMessenger.of(context);
      m.hideCurrentSnackBar();
      m.showSnackBar(SnackBar(content: Text('Added to ${pl.name}')));
    }
    return;
  }
  if (!context.mounted) return;
  await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => PlaylistScreen(playlist: pl)));
}

class _CreateSheet extends StatefulWidget {
  const _CreateSheet();

  @override
  State<_CreateSheet> createState() => _CreateSheetState();
}

class _CreateSheetState extends State<_CreateSheet> {
  final TextEditingController _name = TextEditingController();
  String? _cover;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    try {
      final x = await ImagePicker()
          .pickImage(source: ImageSource.gallery, maxWidth: 1600);
      if (x != null && mounted) setState(() => _cover = x.path);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    const outline = Color(0xFF5A5A5E);

    final ButtonStyle outlined = OutlinedButton.styleFrom(
      foregroundColor: kChipOrange,
      side: BorderSide(color: kChipOrange, width: 1.2),
      minimumSize: const Size(0, 42),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      textStyle: const TextStyle(
          fontFamily: kPoppins, fontSize: 14, fontWeight: FontWeight.w500),
    );

    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                height: 48,
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Create a New Playlist',
                        style: TextStyle(
                          fontFamily: kPoppins,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 28),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _name,
                style: const TextStyle(
                    fontFamily: kPoppins, fontSize: 17, color: Colors.white),
                cursorColor: kChipOrange,
                decoration: InputDecoration(
                  hintText: 'Playlist Title',
                  hintStyle: const TextStyle(
                      fontFamily: kPoppins,
                      fontSize: 17,
                      color: Color(0xFF8E8E93)),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: outline),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: kChipOrange),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: _pick,
                child: AspectRatio(
                  aspectRatio: 1,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: _cover == null
                        ? Image.asset('assets/playlist_default.jpg',
                            fit: BoxFit.cover)
                        : Image.file(File(_cover!), fit: BoxFit.cover),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: outlined,
                      onPressed: _pick,
                      child: const Text('Add Artwork'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      style: outlined,
                      onPressed: () => setState(() => _cover = null),
                      child: const Text('Default Art'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: kChipOrange,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 44),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  textStyle: const TextStyle(
                      fontFamily: kPoppins,
                      fontSize: 16,
                      fontWeight: FontWeight.w500),
                ),
                onPressed: () =>
                    Navigator.pop(context, _NewPlaylist(_name.text, _cover)),
                child: const Text('Create'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
