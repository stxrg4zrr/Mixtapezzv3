import 'package:flutter/material.dart';

const kBlack = Color(0xFF0D0D0D);
const kCard = Color(0xFF181818);
const kChip = Color(0xFF1B1B1C);
const kPill = Color(0xC22C2C2E);
const kGreen = Color(0xFF00E676);
const kMuted = Color(0xFF9A9A9A);
const kRowMuted = Color(0xFFA0A0A3);
const kAmber = Color(0xFFE8A33D);

/// The app color (orange by default). Everything that used to be orange reads
/// these, so changing [Accent.index] recolors the whole app.
class Accent {
  static const List<Color> mains = [Color(0xFFFF5500), Color(0xFF22B5C4), Color(0xFF1DB954)];
  static const List<Color> chips = [Color(0xFFE05A30), Color(0xFF1E9FAE), Color(0xFF1AA34A)];
  static const List<String> names = ['Orange', 'Blue', 'Green'];
  static int index = 0;
  static Color get main => mains[index];
  static Color get chip => chips[index];
}

Color get kOrange => Accent.main;
Color get kChipOrange => Accent.chip;
Color get kOrangeSoft => Accent.main.withAlpha(0x33);

/// Marks every widget dirty so a new app color shows everywhere at once.
void rebuildWholeApp() {
  void visit(Element e) {
    e.markNeedsBuild();
    e.visitChildren(visit);
  }

  WidgetsBinding.instance.rootElement?.visitChildren(visit);
}

/// Font used by the playlist / menu screens (bundled in assets/fonts).
const String kPoppins = 'Poppins';

/// Playlist theme colors (stored as ints).
const kPlaylistColorValues = <int>[
  0xFFE8A33D, // amber
  0xFFFF5500, // cassette orange
  0xFF00E676, // neon green
  0xFFB388FF, // purple
  0xFFFF5252, // red
  0xFF40C4FF, // blue
  0xFFFFD740, // yellow
  0xFFFF80AB, // pink
  0xFF1DE9B6, // teal
  0xFFFFFFFF, // white
  0xFFC6FF00, // lime
  0xFF18FFFF, // cyan
  0xFF7C4DFF, // indigo
  0xFFFF6E40, // coral
];

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    textTheme: base.textTheme.apply(fontFamily: kPoppins),
    primaryTextTheme: base.primaryTextTheme.apply(fontFamily: kPoppins),
    scaffoldBackgroundColor: kBlack,
    colorScheme: const ColorScheme.dark(
      primary: kOrange,
      onPrimary: Colors.black,
      secondary: kGreen,
      surface: kCard,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: kBlack,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: kCard,
      surfaceTintColor: Colors.transparent,
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: kCard,
      contentTextStyle: TextStyle(color: Colors.white),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
