import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:audio_metadata_reader/audio_metadata_reader.dart' show readMetadata;
import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'importer.dart';
import 'models.dart';
import 'text_fix.dart';
import 'theme.dart';

enum SortMode { titleAsc, titleDesc, artistAsc, newest }

enum VideoSort { titleAsc, titleDesc, newest }

class ImportResult {
  const ImportResult(this.ok, this.failures);
  final int ok;
  final List<String> failures;
}

class LibraryStore extends ChangeNotifier {
  LibraryStore._(this._albumBox, this._playlistBox, this._prefs);

  final Box<String> _albumBox;
  final Box<String> _playlistBox;
  final Box<String> _prefs;

  List<Album> _albums = [];
  List<Playlist> _playlists = [];
  Map<String, TrackRef> _index = {};

  String query = '';
  String videoQuery = ''; // the search box inside the Videos tab
  SortMode sort = SortMode.titleAsc;
  VideoSort videoSort = VideoSort.titleAsc;
  bool importing = false;
  String? status;
  double? progress;

  static Future<LibraryStore> open() async {
    final a = await Hive.openBox<String>('albums');
    final pl = await Hive.openBox<String>('playlists');
    final pr = await Hive.openBox<String>('prefs');
    final s = LibraryStore._(a, pl, pr);
    s._load();
    await s._ensureFavorites();
    await s._repairText();
    return s;
  }

  // ---------------------------------------------------------------- loading

  void _load() {
    final albums = <Album>[];
    for (final v in _albumBox.values) {
      try {
        albums.add(Album.fromJson(Map<String, dynamic>.from(jsonDecode(v) as Map)));
      } catch (_) {}
    }
    _albums = albums;

    final lists = <Playlist>[];
    for (final v in _playlistBox.values) {
      try {
        lists.add(Playlist.fromJson(Map<String, dynamic>.from(jsonDecode(v) as Map)));
      } catch (_) {}
    }
    _playlists = lists;

    final ac = int.tryParse(_prefs.get('accent') ?? '');
    if (ac != null && ac >= 0 && ac < Accent.mains.length) Accent.index = ac;

    final s = int.tryParse(_prefs.get('sort') ?? '');
    if (s != null && s >= 0 && s < SortMode.values.length) sort = SortMode.values[s];

    _reindex();
    for (final pl in _playlists) {
      pl.trackIds.removeWhere((id) => !_index.containsKey(id));
    }
  }

  void _reindex() {
    _index = {
      for (final a in _albums)
        for (final t in a.tracks) t.id: TrackRef(t, a),
    };
  }

  /// Heals names that were imported with garbled tag text.
  Future<void> _repairText() async {
    for (final a in _albums) {
      var changed = false;
      final t = fixTagText(a.title);
      if (t.isNotEmpty && t != a.title) {
        a.title = t;
        changed = true;
      }
      final ar = fixTagText(a.artist);
      if (ar.isNotEmpty && ar != a.artist) {
        a.artist = ar;
        changed = true;
      }
      for (final tr in a.tracks) {
        final x = fixTagText(tr.title);
        if (x.isNotEmpty && x != tr.title) {
          tr.title = x;
          changed = true;
        }
      }
      if (changed) await _saveAlbum(a);
    }
  }

  Future<void> _ensureFavorites() async {
    if (_playlists.any((x) => x.isFavorites)) return;
    final fav = Playlist(id: 'favorites', name: 'Favorites', colorValue: 0xFFE8A33D);
    _playlists.add(fav);
    await _savePlaylist(fav);
  }

  // ------------------------------------------------------------------ albums

  int get count => _albums.where((a) => !a.hidden).length;
  int get trackCount => _index.length;
  int get visibleTrackCount => _albums
      .where((a) => !a.hidden)
      .fold<int>(0, (sum, a) => sum + a.tracks.length);
  int get artistCount => _albums.map((a) => a.artist.toLowerCase()).toSet().length;

  TrackRef? ref(String trackId) => _index[trackId];

  List<TrackRef> tracksOf(Album a) =>
      a.tracks.map((t) => TrackRef(t, a)).toList();

  /// Key used for sorting and for the alphabet scroller.
  String keyOf(Album a) => sort == SortMode.artistAsc ? a.artist : a.title;

  Iterable<Album> _filtered() {
    final q = query.trim().toLowerCase();
    final visible = _albums.where((a) => !a.hidden);
    if (q.isEmpty) return visible;
    return visible.where((a) =>
        a.title.toLowerCase().contains(q) || a.artist.toLowerCase().contains(q));
  }

  int _cmp(Album a, Album b) {
    switch (sort) {
      case SortMode.titleAsc:
        return a.title.toLowerCase().compareTo(b.title.toLowerCase());
      case SortMode.titleDesc:
        return b.title.toLowerCase().compareTo(a.title.toLowerCase());
      case SortMode.artistAsc:
        {
          final c = a.artist.toLowerCase().compareTo(b.artist.toLowerCase());
          return c != 0 ? c : a.title.toLowerCase().compareTo(b.title.toLowerCase());
        }
      case SortMode.newest:
        return b.addedAt.compareTo(a.addedAt);
    }
  }

  List<Album> get albums => _filtered().toList()..sort(_cmp);
  List<Album> get pinned => _filtered().where((a) => a.pinned).toList()..sort(_cmp);

  List<TrackRef> get allAudio {
    final all = <TrackRef>[];
    for (final a in _albums) {
      if (a.hidden) continue;
      for (final t in a.tracks) {
        if (!t.isVideo) all.add(TrackRef(t, a));
      }
    }
    if (all.isNotEmpty) return all;
    return [
      for (final a in _albums)
        for (final t in a.tracks) TrackRef(t, a),
    ];
  }

  List<TrackRef> get videos {
    final q = videoQuery.trim().toLowerCase();
    final out = <TrackRef>[];
    for (final a in _albums) {
      for (final t in a.tracks) {
        if (!t.isVideo) continue;
        if (q.isNotEmpty &&
            !t.title.toLowerCase().contains(q) &&
            !a.title.toLowerCase().contains(q) &&
            !a.artist.toLowerCase().contains(q)) {
          continue;
        }
        out.add(TrackRef(t, a));
      }
    }
    switch (videoSort) {
      case VideoSort.titleAsc:
        out.sort((x, y) =>
            x.track.title.toLowerCase().compareTo(y.track.title.toLowerCase()));
        break;
      case VideoSort.titleDesc:
        out.sort((x, y) =>
            y.track.title.toLowerCase().compareTo(x.track.title.toLowerCase()));
        break;
      case VideoSort.newest:
        out.sort((x, y) => y.album.addedAt.compareTo(x.album.addedAt));
        break;
    }
    return out;
  }

  void setQuery(String q) {
    query = q;
    notifyListeners();
  }

  void setVideoQuery(String q) {
    videoQuery = q;
    notifyListeners();
  }

  /// App color: 0 orange (default), 1 blue, 2 green.
  Future<void> setAccent(int i) async {
    if (i < 0 || i >= Accent.mains.length) return;
    Accent.index = i;
    await _prefs.put('accent', i.toString());
    rebuildWholeApp();
  }

  void setVideoSort(VideoSort m) {
    videoSort = m;
    notifyListeners();
  }

  Future<void> setSort(SortMode m) async {
    sort = m;
    await _prefs.put('sort', m.index.toString());
    notifyListeners();
  }

  Future<void> _saveAlbum(Album a) => _albumBox.put(a.id, jsonEncode(a.toJson()));

  Future<void> togglePin(Album a) async {
    a.pinned = !a.pinned;
    await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> updateAlbum(
    Album a, {
    required String title,
    required String artist,
    Map<String, String> trackTitles = const {},
  }) async {
    if (title.trim().isNotEmpty) a.title = title.trim();
    if (artist.trim().isNotEmpty) a.artist = artist.trim();
    for (final t in a.tracks) {
      final nt = trackTitles[t.id];
      if (nt != null && nt.trim().isNotEmpty) t.title = nt.trim();
    }
    await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> setAlbumCover(Album a, String srcPath) async {
    final ext = p.extension(srcPath).isEmpty ? '.jpg' : p.extension(srcPath);
    final dest = p.join(a.dirPath, 'cover_custom_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(srcPath).copy(dest);
    final old = a.coverPath;
    a.coverPath = dest;
    if (old != null && p.basename(old).startsWith('cover_custom_')) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> deleteAlbum(Album a) async {
    final ids = a.tracks.map((t) => t.id).toSet();
    _albums.removeWhere((x) => x.id == a.id);
    _reindex();
    await _albumBox.delete(a.id);
    for (final pl in _playlists) {
      final before = pl.trackIds.length;
      pl.trackIds.removeWhere(ids.contains);
      if (pl.trackIds.length != before) await _savePlaylist(pl);
    }
    try {
      await Directory(a.dirPath).delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  /// Removes one video (file + library entry). If it was the last track of its
  /// tape/album, the whole entry goes.
  Future<void> deleteVideo(TrackRef r) async {
    final a = r.album;
    final t = r.track;
    a.tracks.removeWhere((x) => x.id == t.id);
    try {
      await File(t.path).delete();
    } catch (_) {}
    for (final pl in _playlists) {
      if (pl.trackIds.remove(t.id)) await _savePlaylist(pl);
    }
    if (a.tracks.isEmpty) {
      await deleteAlbum(a);
    } else {
      _reindex();
      await _saveAlbum(a);
      notifyListeners();
    }
  }

  /// Renames one track / video (only inside the app; the file is untouched).
  Future<void> renameTrack(Track t, String title) async {
    final clean = title.trim();
    if (clean.isEmpty) return;
    t.title = clean;
    final a = _index[t.id]?.album;
    if (a != null) await _saveAlbum(a);
    notifyListeners();
  }

  Future<void> _audioChain = Future<void>.value();

  /// Reads an audio track's length once (for the track lists) and keeps it in
  /// memory. One at a time, so the list stays smooth.
  Future<void> ensureAudioDuration(Track t) {
    if (t.durationMs != null || t.isVideo) return Future<void>.value();
    final done = Completer<void>();
    _audioChain = _audioChain.then((_) async {
      if (t.durationMs == null) {
        var ms = 0;
        try {
          final dynamic md = readMetadata(File(t.path), getImage: false);
          final d = md.duration;
          if (d is Duration) ms = d.inMilliseconds;
        } catch (_) {}
        t.durationMs = ms;
      }
      await Future<void>.delayed(Duration.zero);
      done.complete();
    });
    return done.future;
  }

  Future<void> _durChain = Future<void>.value();

  /// Reads a video's length once (for the Videos tab) and remembers it.
  Future<void> ensureVideoDuration(Track t) {
    if (t.durationMs != null) return Future<void>.value();
    final done = Completer<void>();
    _durChain = _durChain.then((_) async {
      if (t.durationMs == null) {
        VideoPlayerController? vc;
        try {
          vc = VideoPlayerController.file(File(t.path));
          await vc.initialize();
          t.durationMs = vc.value.duration.inMilliseconds;
        } catch (_) {
          t.durationMs = 0;
        } finally {
          try {
            await vc?.dispose();
          } catch (_) {}
        }
        final a = _index[t.id]?.album;
        if (a != null) await _saveAlbum(a);
        notifyListeners();
      }
      done.complete();
    });
    return done.future;
  }

  // ---------------------------------------------------------------- playlists

  Playlist get favorites => _playlists.firstWhere((x) => x.isFavorites);

  List<Playlist> get playlists {
    final q = query.trim().toLowerCase();
    final l = _playlists
        .where((x) => q.isEmpty || x.name.toLowerCase().contains(q))
        .toList();
    l.sort((a, b) {
      if (a.isFavorites) return -1;
      if (b.isFavorites) return 1;
      return a.name.toLowerCase().compareTo(b.name.toLowerCase());
    });
    return l;
  }

  List<TrackRef> playlistTracks(Playlist x) =>
      x.trackIds.map((id) => _index[id]).whereType<TrackRef>().toList();

  int get playlistTrackTotal {
    final ids = <String>{};
    for (final x in _playlists) {
      ids.addAll(x.trackIds);
    }
    return ids.length;
  }

  int get playlistArtistTotal {
    final artists = <String>{};
    for (final x in _playlists) {
      for (final id in x.trackIds) {
        final r = _index[id];
        if (r != null) artists.add(r.album.artist.toLowerCase());
      }
    }
    return artists.length;
  }

  Future<void> _savePlaylist(Playlist x) =>
      _playlistBox.put(x.id, jsonEncode(x.toJson()));

  Future<Playlist> createPlaylist(String name, int colorValue) async {
    final x = Playlist(
      id: 'pl_${DateTime.now().microsecondsSinceEpoch}',
      name: name.trim().isEmpty ? 'New playlist' : name.trim(),
      colorValue: colorValue,
    );
    _playlists.add(x);
    await _savePlaylist(x);
    notifyListeners();
    return x;
  }

  Future<void> updatePlaylist(Playlist x, {String? name, int? colorValue}) async {
    if (name != null && name.trim().isNotEmpty && !x.isFavorites) x.name = name.trim();
    if (colorValue != null) x.colorValue = colorValue;
    await _savePlaylist(x);
    notifyListeners();
  }

  Future<void> setPlaylistCover(Playlist x, String srcPath) async {
    final dir = await getApplicationSupportDirectory();
    final d = Directory(p.join(dir.path, 'playlist_covers'));
    await d.create(recursive: true);
    final ext = p.extension(srcPath).isEmpty ? '.jpg' : p.extension(srcPath);
    final dest = p.join(d.path, '${x.id}_${DateTime.now().millisecondsSinceEpoch}$ext');
    await File(srcPath).copy(dest);
    final old = x.coverPath;
    x.coverPath = dest;
    if (old != null) {
      try {
        await File(old).delete();
      } catch (_) {}
    }
    await _savePlaylist(x);
    notifyListeners();
  }

  Future<void> deletePlaylist(Playlist x) async {
    if (x.isFavorites) return;
    _playlists.removeWhere((y) => y.id == x.id);
    await _playlistBox.delete(x.id);
    if (x.coverPath != null) {
      try {
        await File(x.coverPath!).delete();
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<int> addToPlaylist(Playlist x, List<String> ids) async {
    var added = 0;
    for (final id in ids) {
      if (!x.trackIds.contains(id) && _index.containsKey(id)) {
        x.trackIds.add(id);
        added++;
      }
    }
    if (added > 0) {
      await _savePlaylist(x);
      notifyListeners();
    }
    return added;
  }

  Future<void> removeFromPlaylist(Playlist x, String id) async {
    x.trackIds.remove(id);
    await _savePlaylist(x);
    notifyListeners();
  }

  Future<void> reorderPlaylist(Playlist x, int oldIndex, int newIndex) async {
    if (oldIndex < 0 || oldIndex >= x.trackIds.length) return;
    final id = x.trackIds.removeAt(oldIndex);
    x.trackIds.insert(newIndex.clamp(0, x.trackIds.length).toInt(), id);
    await _savePlaylist(x);
    notifyListeners();
  }

  bool isFavorite(String trackId) => favorites.trackIds.contains(trackId);

  Future<void> toggleFavorite(String trackId) async {
    final f = favorites;
    if (f.trackIds.contains(trackId)) {
      f.trackIds.remove(trackId);
    } else if (_index.containsKey(trackId)) {
      f.trackIds.add(trackId);
    }
    await _savePlaylist(f);
    notifyListeners();
  }

  // ------------------------------------------------------------------ import

  void _deleteCached(String path) {
    try {
      if (path.contains('/cache/')) File(path).deleteSync();
    } catch (_) {}
  }

  /// Each entry is zipPath -> display name. One bad zip never stops the rest.
  Future<ImportResult> importZips(List<MapEntry<String, String>> zips) async {
    importing = true;
    progress = 0;
    notifyListeners();
    try {
      await WakelockPlus.enable(); // keep the screen on during big batches
    } catch (_) {}
    var ok = 0;
    final failures = <String>[];

    for (var i = 0; i < zips.length; i++) {
      final z = zips[i];
      status = 'Eating ${i + 1} of ${zips.length}\n${z.value}';
      progress = i / zips.length;
      notifyListeners();
      try {
        final ext = p.extension(z.value).toLowerCase();
        final Album a;
        if (ext == '.zip') {
          a = await Importer.importZip(z.key, z.value);
        } else if (ext == '.mp4' || ext == '.mov' || ext == '.m4v') {
          a = await Importer.importVideo(z.key, z.value);
        } else {
          throw Exception('Only .zip and .mp4 files can be imported');
        }
        _albums.add(a);
        _reindex();
        await _saveAlbum(a);
        ok++;
        notifyListeners();
      } catch (e) {
        final msg = e.toString().replaceFirst('Exception: ', '');
        failures.add('${z.value}: $msg');
      } finally {
        _deleteCached(z.key);
      }
    }

    try {
      await WakelockPlus.disable();
    } catch (_) {}
    importing = false;
    status = null;
    progress = null;
    notifyListeners();
    return ImportResult(ok, failures);
  }
}
