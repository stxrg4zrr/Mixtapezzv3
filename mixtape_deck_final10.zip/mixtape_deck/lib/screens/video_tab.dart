import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../utils.dart';
import '../video_actions.dart';
import 'video_screen.dart';

class VideoTab extends StatefulWidget {
  const VideoTab({super.key});

  @override
  State<VideoTab> createState() => _VideoTabState();
}

class _VideoTabState extends State<VideoTab> {
  bool _searching = false;

  void _closeSearch(LibraryStore store) {
    setState(() => _searching = false);
    store.setVideoQuery('');
    FocusManager.instance.primaryFocus?.unfocus();
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final videos = store.videos;

    return ListView(
      padding: const EdgeInsets.only(bottom: 100),
      children: [
        SizedBox(
          height: 52,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(17, 2, 12, 0),
            child: SizedBox(
              height: 48,
              child: _searching
                  ? Row(
                      children: [
                        Expanded(
                          child: TextField(
                            autofocus: true,
                            onChanged: store.setVideoQuery,
                            style: const TextStyle(fontSize: 15),
                            decoration: InputDecoration(
                              hintText: 'Search videos',
                              prefixIcon: const Icon(Icons.search, size: 20),
                              filled: true,
                              fillColor: kChip,
                              contentPadding: EdgeInsets.zero,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => _closeSearch(store),
                        ),
                      ],
                    )
                  : Row(
                      children: [
                        const Text('All',
                            style:
                                TextStyle(fontSize: 20, fontWeight: FontWeight.w400)),
                        const Spacer(),
                        IconButton(
                          icon: const Icon(Icons.search),
                          onPressed: () => setState(() => _searching = true),
                        ),
                        IconButton(
                          icon: const Icon(Icons.filter_list_rounded),
                          onPressed: () => _sortSheet(context, store),
                        ),
                      ],
                    ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (videos.isEmpty)
          const Padding(
            padding: EdgeInsets.fromLTRB(32, 24, 32, 0),
            child: Text(
              'No videos yet.\nTap + and pick an .mp4, or eat a tape that has videos.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kMuted, fontSize: 16, height: 1.6),
            ),
          ),
        for (final v in videos) _VideoRow(key: ValueKey(v.track.id), item: v),
        Padding(
          padding: const EdgeInsets.only(top: 18),
          child: Center(
            child: Text('${videos.length} Videos',
                style: const TextStyle(color: kRowMuted, fontSize: 16)),
          ),
        ),
      ],
    );
  }

  void _sortSheet(BuildContext context, LibraryStore store) {
    Widget opt(VideoSort m, String label) => ListTile(
          title: Text(label),
          trailing: store.videoSort == m
              ? Icon(Icons.check_rounded, color: kOrange)
              : null,
          onTap: () {
            store.setVideoSort(m);
            Navigator.pop(context);
          },
        );
    showModalBottomSheet<void>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Sort videos',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            opt(VideoSort.titleAsc, 'Title  A to Z'),
            opt(VideoSort.titleDesc, 'Title  Z to A'),
            opt(VideoSort.newest, 'Recently added'),
          ],
        ),
      ),
    );
  }
}

class _VideoRow extends StatefulWidget {
  const _VideoRow({super.key, required this.item});

  final TrackRef item;

  @override
  State<_VideoRow> createState() => _VideoRowState();
}

class _VideoRowState extends State<_VideoRow> {
  @override
  void initState() {
    super.initState();
    context.read<LibraryStore>().ensureVideoDuration(widget.item.track);
  }

  void _open() {
    Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => VideoScreen(item: widget.item)));
  }

  Future<void> _delete() async {
    final store = context.read<LibraryStore>();
    final player = context.read<PlayerController>();
    final r = widget.item;
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Delete this video?'),
        content: Text('"${r.track.title}" will be removed from this phone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(d, true),
              child: const Text('Delete', style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (ok == true) {
      if (player.current?.track.id == r.track.id) await player.stop();
      await store.deleteVideo(r);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.item;
    final ms = r.track.durationMs ?? 0;

    // The tape picture itself is not clickable; use the play button.
    return Padding(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: Image.asset(
                'assets/vhs_tape.png',
                width: 64,
                height: 95,
                fit: BoxFit.fill,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    r.track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    ms > 0 ? fmtDuration(Duration(milliseconds: ms)) : ' ',
                    style: const TextStyle(fontSize: 20, color: kRowMuted),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.more_horiz),
                        position: PopupMenuPosition.under,
                        color: const Color(0xFF1F1F27),
                        surfaceTintColor: Colors.transparent,
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6)),
                        onSelected: (v) {
                          if (v == 'subs') {
                            addSubtitlesToVideo(context, r);
                          } else if (v == 'title') {
                            editVideoTitle(context, r);
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem<String>(
                            value: 'subs',
                            child: Text('Add Subtitles',
                                style: TextStyle(
                                    fontFamily: kPoppins,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500)),
                          ),
                          PopupMenuItem<String>(
                            value: 'title',
                            child: Text('Edit Title',
                                style: TextStyle(
                                    fontFamily: kPoppins,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500)),
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: _open,
                        child: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: kChipOrange,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Icon(Icons.play_arrow_rounded,
                              color: Colors.white, size: 32),
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: kRowMuted),
                        onPressed: _delete,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
    );
  }
}
