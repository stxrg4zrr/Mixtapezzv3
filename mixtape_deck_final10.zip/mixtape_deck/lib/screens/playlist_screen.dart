import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../player_controller.dart';
import '../theme.dart';
import '../widgets/add_tracks_sheet.dart';
import '../widgets/bottom_deck.dart';
import '../widgets/cover_image.dart';
import '../widgets/dithered_background.dart';
import '../widgets/menus.dart';
import '../widgets/playlist_cover.dart';

/// Playlist page: back + "Add Tracks", cover, title, shuffle + play,
/// "N Tracks / M min", the tracks (drag the handle to reorder), bottom bar.
class PlaylistScreen extends StatefulWidget {
  const PlaylistScreen({super.key, required this.playlist});

  final Playlist playlist;

  @override
  State<PlaylistScreen> createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  final Set<String> _asked = {};

  // Reads the length of every track once so the "M min" total is right.
  void _askDurations(List<TrackRef> tracks) {
    final store = context.read<LibraryStore>();
    final todo = tracks
        .where((r) =>
            r.track.durationMs == null && !r.track.isVideo && _asked.add(r.track.id))
        .toList();
    if (todo.isEmpty) return;
    () async {
      for (final r in todo) {
        await store.ensureAudioDuration(r.track);
      }
      if (mounted) setState(() {});
    }();
  }

  void _dotsMenu() {
    final store = context.read<LibraryStore>();
    final playlist = widget.playlist;
    final nav = Navigator.of(context);
    showModalBottomSheet<void>(
      context: context,
      builder: (sheet) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.edit_outlined, color: kOrange),
              title: const Text('Edit playlist'),
              onTap: () {
                Navigator.pop(sheet);
                showPlaylistEditor(context, existing: playlist);
              },
            ),
            if (!playlist.isFavorites)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
                title: const Text('Delete playlist'),
                onTap: () async {
                  Navigator.pop(sheet);
                  await store.deletePlaylist(playlist);
                  nav.maybePop();
                },
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final pl = context.watch<PlayerController>();
    final playlist = widget.playlist;
    final tracks = store.playlistTracks(playlist);
    final curId = pl.current?.track.id;
    final empty = tracks.isEmpty;

    _askDurations(tracks);
    final totalMs = tracks.fold<int>(0, (sum, r) => sum + (r.track.durationMs ?? 0));
    final mins = (totalMs / 60000).round();
    final info =
        '${tracks.length} ${tracks.length == 1 ? 'Track' : 'Tracks'} / $mins min';

    final dim = empty ? 0.38 : 1.0;

    return DitheredBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          bottom: false,
          child: Stack(
            children: [
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(4, 4, 8, 0),
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => Navigator.of(context).maybePop(),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: () => showAddTracksSheet(context, playlist),
                          child: Text(
                            'Add Tracks',
                            style: TextStyle(
                              fontFamily: kPoppins,
                              fontSize: 16.5,
                              color: kChipOrange,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: CustomScrollView(
                      slivers: [
                        SliverToBoxAdapter(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                                child: AspectRatio(
                                  aspectRatio: 1,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(22),
                                    child: PlaylistCover(
                                        playlist: playlist, cacheWidth: 1000),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 22, 16, 0),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            playlist.name,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontFamily: kPoppins,
                                              fontSize: 22,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white,
                                            ),
                                          ),
                                          const Text(
                                            'by Me',
                                            style: TextStyle(
                                              fontFamily: kPoppins,
                                              fontSize: 16,
                                              color: Color(0xFFB5B5B8),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      icon: Icon(
                                        Icons.shuffle_rounded,
                                        size: 30,
                                        color: kChipOrange.withAlpha((255 * dim).round()),
                                      ),
                                      onPressed: empty
                                          ? null
                                          : () => pl.playQueue(tracks, 0, shuffleOn: true),
                                    ),
                                    const SizedBox(width: 8),
                                    GestureDetector(
                                      onTap: empty ? null : () => pl.playQueue(tracks, 0),
                                      child: Container(
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          color: kChipOrange.withAlpha((255 * (empty ? 0.4 : 1.0)).round()),
                                          borderRadius: BorderRadius.circular(18),
                                        ),
                                        child: const Icon(Icons.play_arrow_rounded,
                                            color: Colors.white, size: 34),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 26, bottom: 14),
                                child: Center(
                                  child: Text(
                                    info,
                                    style: TextStyle(
                                      fontFamily: kPoppins,
                                      fontSize: 13,
                                      color: kChipOrange,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SliverReorderableList(
                          itemCount: tracks.length,
                          onReorder: (o, n) {
                            if (n > o) n -= 1;
                            store.reorderPlaylist(playlist, o, n);
                          },
                          itemBuilder: (c, i) {
                            final r = tracks[i];
                            final active = curId == r.track.id;
                            return Material(
                              key: ValueKey('${r.track.id}_$i'),
                              type: MaterialType.transparency,
                              child: ListTile(
                                onTap: () => pl.playQueue(tracks, i),
                                onLongPress: () =>
                                    showTrackMenu(context, r, fromPlaylist: playlist),
                                leading: ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: SizedBox(
                                    width: 44,
                                    height: 44,
                                    child: CoverImage(
                                        path: r.album.coverPath, cacheWidth: 140),
                                  ),
                                ),
                                title: Text(
                                  r.track.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontFamily: kPoppins,
                                    fontSize: 16,
                                    color: active ? kChipOrange : Colors.white,
                                  ),
                                ),
                                subtitle: Text(
                                  r.album.artist,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontFamily: kPoppins,
                                    fontSize: 12.5,
                                    color: Color(0xFF9A9A9E),
                                  ),
                                ),
                                trailing: ReorderableDragStartListener(
                                  index: i,
                                  child: const Icon(Icons.drag_handle,
                                      color: Colors.white38),
                                ),
                              ),
                            );
                          },
                        ),
                        const SliverToBoxAdapter(child: SizedBox(height: 120)),
                      ],
                    ),
                  ),
                ],
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: BottomDeck(onDots: _dotsMenu, showProgress: true),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
