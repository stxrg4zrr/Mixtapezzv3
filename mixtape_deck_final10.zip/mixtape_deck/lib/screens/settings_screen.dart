import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../theme.dart';
import '../widgets/eat_tape.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: kCard,
            child: ListTile(
              leading: Icon(Icons.add_circle, color: kOrange),
              title: const Text('Eat a tape',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text(
                  'Pick .zip mixtapes or .mp4 videos, hundreds at once is fine. Keep the app open while it works.'),
              onTap: store.importing ? null : () => eatTape(context),
            ),
          ),
          Card(
            color: kCard,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.palette_outlined, color: kOrange),
                      const SizedBox(width: 16),
                      const Text('App color',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Padding(
                    padding: EdgeInsets.only(left: 40),
                    child: Text('Changes every accent color in the app.',
                        style: TextStyle(color: kMuted, fontSize: 13)),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      for (var i = 0; i < Accent.mains.length; i++) ...[
                        GestureDetector(
                          onTap: () => store.setAccent(i),
                          child: Column(
                            children: [
                              Container(
                                width: 52,
                                height: 52,
                                decoration: BoxDecoration(
                                  color: Accent.mains[i],
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Accent.index == i
                                        ? Colors.white
                                        : Colors.transparent,
                                    width: 3,
                                  ),
                                ),
                                child: Accent.index == i
                                    ? const Icon(Icons.check, color: Colors.white)
                                    : null,
                              ),
                              const SizedBox(height: 6),
                              Text(i == 0 ? 'Orange (default)' : Accent.names[i],
                                  style: const TextStyle(color: kMuted, fontSize: 11)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 18),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
          Card(
            color: kCard,
            child: ListTile(
              leading: Icon(Icons.album, color: kOrange),
              title: Text('${store.count} tapes  ·  ${store.trackCount} tracks'),
              subtitle: const Text(
                  'Files are copied into the app\'s private storage. Deleting a tape removes them.'),
            ),
          ),
          FutureBuilder<PermissionStatus>(
            future: Permission.notification.status,
            builder: (context, snap) {
              final ok = snap.data?.isGranted ?? false;
              return Card(
                color: kCard,
                child: ListTile(
                  leading: Icon(
                    ok ? Icons.notifications_active : Icons.notifications_off_outlined,
                    color: ok ? kGreen : kOrange,
                  ),
                  title: const Text('Lock screen controls'),
                  subtitle: Text(ok
                      ? 'On. The player shows on the lock screen and in quick settings while music plays.'
                      : 'Off. Tap to allow notifications, otherwise Android hides the player.'),
                  trailing: const Icon(Icons.open_in_new, size: 18, color: kMuted),
                  onTap: () async {
                    final st = await Permission.notification.request();
                    if (!st.isGranted) await openAppSettings();
                  },
                ),
              );
            },
          ),
          const Card(
            color: kCard,
            child: ListTile(
              leading: Icon(Icons.cloud_off, color: kGreen),
              title: Text('Fully offline'),
              subtitle: Text(
                  'No login, no cloud, no scanning of your phone. Only what you import.'),
            ),
          ),
          Card(
            color: kCard,
            child: ListTile(
              leading: Icon(Icons.edit_note, color: kOrange),
              title: Text('Tag edits'),
              subtitle: Text(
                  'Renames and covers are saved inside Mixtapezz. Your original files are never changed.'),
            ),
          ),
        ],
      ),
    );
  }
}
