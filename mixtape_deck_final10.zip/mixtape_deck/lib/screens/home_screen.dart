import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_keys.dart';
import '../library_store.dart';
import '../theme.dart';
import '../widgets/bottom_deck.dart';
import '../widgets/create_playlist_sheet.dart';
import '../widgets/dithered_background.dart';
import '../widgets/eat_tape.dart';
import 'playlists_tab.dart';
import 'settings_screen.dart';
import 'tapes_tab.dart';
import 'video_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  bool _searching = false;
  bool _fabOpen = false; // the "+" menu (Import Files / Create Playlist)
  bool _showTabs = true; // Tapes / Playlists / Videos row

  static const _names = ['Tapes', 'Playlists', 'Videos'];

  void _closeSearch() {
    setState(() => _searching = false);
    context.read<LibraryStore>().setQuery('');
    FocusManager.instance.primaryFocus?.unfocus();
  }

  // Back button: close the search first; otherwise go to the background
  // (never close the app, so the music keeps playing).
  void _onBack(bool didPop, Object? result) {
    if (didPop) return;
    if (_fabOpen) {
      setState(() => _fabOpen = false);
    } else if (_searching) {
      _closeSearch();
    } else {
      moveAppToBack();
    }
  }

  // Hide the tab row while scrolling down; bring it back only at the very top.
  bool _onScroll(ScrollNotification n) {
    if (n.depth != 0 || n.metrics.axis != Axis.vertical) return false;
    if (n is! ScrollUpdateNotification && n is! ScrollEndNotification) {
      return false;
    }
    final px = n.metrics.pixels;
    if (_showTabs) {
      if (px > 30 && n.metrics.maxScrollExtent > 260 && mounted) {
        setState(() => _showTabs = false);
      }
    } else if (px <= 0.5 && mounted) {
      setState(() => _showTabs = true);
    }
    return false;
  }

  Widget _tabRow() {
    return SizedBox(
      height: 30,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          for (var i = 0; i < _names.length; i++) ...[
            GestureDetector(
              onTap: () => setState(() => _tab = i),
              child: Container(
                height: 30,
                padding: const EdgeInsets.symmetric(horizontal: 18),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: _tab == i ? kChipOrange : kChip,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _names[i],
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
          ],
        ],
      ),
    );
  }

  Widget _fabMenu(double bottomInset) {
    Widget anim(Widget child, int ms) => AnimatedSlide(
          offset: _fabOpen ? Offset.zero : const Offset(0, 0.35),
          duration: Duration(milliseconds: ms),
          curve: Curves.easeOutCubic,
          child: AnimatedOpacity(
            opacity: _fabOpen ? 1 : 0,
            duration: Duration(milliseconds: ms),
            child: child,
          ),
        );

    return Positioned(
      right: 10,
      bottom: bottomInset + 82,
      child: IgnorePointer(
        ignoring: !_fabOpen,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            anim(
              _MenuPill(
                icon: Icons.audio_file_rounded,
                label: 'Import Files',
                onTap: () {
                  setState(() => _fabOpen = false);
                  eatTape(context);
                },
              ),
              300,
            ),
            const SizedBox(height: 13),
            anim(
              _MenuPill(
                icon: Icons.playlist_add_rounded,
                label: 'Create Playlist',
                onTap: () {
                  setState(() => _fabOpen = false);
                  showCreatePlaylistSheet(context);
                },
              ),
              220,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<LibraryStore>();
    final bottomInset = MediaQuery.of(context).padding.bottom;

    return DitheredBackground(
      child: PopScope(
        canPop: false,
        onPopInvokedWithResult: _onBack,
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            bottom: false,
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(18, 12, 4, 0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Transform.scale(
                              scaleX: 1.1,
                              scaleY: 1.0,
                              alignment: Alignment.centerLeft,
                              child: const Text(
                                'MIXTAPEZZ',
                                maxLines: 1,
                                style: TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ),
                          ),
                          IconButton(
                            icon: Icon(_searching ? Icons.close : Icons.search),
                            onPressed: () {
                              if (_searching) {
                                _closeSearch();
                              } else {
                                setState(() => _searching = true);
                              }
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.settings),
                            onPressed: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                    builder: (_) => const SettingsScreen())),
                          ),
                        ],
                      ),
                    ),
                    if (_searching)
                      Padding(
                        padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                        child: SizedBox(
                          height: 40,
                          child: TextField(
                            autofocus: true,
                            onChanged: store.setQuery,
                            style: const TextStyle(fontSize: 15),
                            decoration: InputDecoration(
                              hintText: 'Search title or artist',
                              prefixIcon: const Icon(Icons.search, size: 20),
                              filled: true,
                              fillColor: kChip,
                              contentPadding: EdgeInsets.zero,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ClipRect(
                      child: AnimatedAlign(
                        alignment: Alignment.topCenter,
                        heightFactor: _showTabs ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOutCubic,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(height: 24),
                            _tabRow(),
                          ],
                        ),
                      ),
                    ),
                    if (store.importing) ...[
                      const SizedBox(height: 8),
                      LinearProgressIndicator(
                        value: store.progress,
                        color: kOrange,
                        backgroundColor: Colors.white12,
                        minHeight: 2,
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                        child: Text(store.status ?? 'Working…',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: kMuted, fontSize: 12)),
                      ),
                    ],
                    Expanded(
                      child: NotificationListener<ScrollNotification>(
                        onNotification: _onScroll,
                        child: IndexedStack(
                          index: _tab,
                          children: [
                            const TapesTab(),
                            const PlaylistsTab(),
                            const VideoTab(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                if (_fabOpen)
                  Positioned.fill(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => setState(() => _fabOpen = false),
                      child: const SizedBox.expand(),
                    ),
                  ),
                _fabMenu(bottomInset),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: BottomDeck(
                    fabOpen: _fabOpen,
                    onPlus: () => setState(() => _fabOpen = !_fabOpen),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// One rounded button of the "+" menu.
class _MenuPill extends StatelessWidget {
  const _MenuPill({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: const Color(0xF21E1E20),
          borderRadius: BorderRadius.circular(22),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 24, color: Colors.white),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(
                fontFamily: kPoppins,
                fontSize: 14.3,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
