# Mixtapezz

Offline-first mixtape player. No login, no cloud, no scanning of your phone.
The library holds only the .zip tapes you "Eat".

Build the APK:

    bash setup.sh
    flutter build apk --release

APK: build/app/outputs/flutter-apk/app-release.apk
