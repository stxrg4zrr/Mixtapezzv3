import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../models.dart';
import '../theme.dart';
import '../utils.dart';
import 'cover_image.dart';

/// Full-screen "Add Tracks" sheet: search box + every track, tap to add/remove.
Future<void> showAddTracksSheet(BuildContext context, Playlist playlist) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: false,
    backgroundColor: const Color(0xFF1C1C1E),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
    ),
    builder: (_) => _AddTracksSheet(playlist: playlist),
  );
}

class _AddTracksSheet extends StatefulWidget {
  const _AddTracksSheet({required this.playlist});

  final Playlist playlist;

  @override
  State<_AddTracksSheet> createState() => _AddTracksSheetState();
}

class _AddTracksSheetState extends State<_AddTracksSheet> {
  final TextEditingController _q = TextEditingController();
  String _query = '';
  late final List<TrackRef> _all;

  @override
  void initState() {
    super.initState();
    final list = context
        .read<LibraryStore>()
        .allAudio
        .where((r) => !r.track.isVideo)
        .toList();
    list.sort((a, b) =>
        a.track.title.toLowerCase().compareTo(b.track.title.toLowerCase()));
    _all = list;
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _toggle(TrackRef r) async {
    final store = context.read<LibraryStore>();
    final pl = widget.playlist;
    if (pl.trackIds.contains(r.track.id)) {
      await store.removeFromPlaylist(pl, r.track.id);
    } else {
      await store.addToPlaylist(pl, [r.track.id]);
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final visible = _query.isEmpty
        ? _all
        : _all
            .where((r) =>
                r.track.title.toLowerCase().contains(_query) ||
                r.album.artist.toLowerCase().contains(_query))
            .toList();

    return SizedBox(
      height: mq.size.height,
      child: Padding(
        padding: EdgeInsets.only(bottom: mq.viewInsets.bottom),
        child: Column(
          children: [
            SizedBox(height: math.max(0.0, mq.padding.top - 6)),
            Center(
              child: Container(
                width: 32,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFF8A8A8E),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 32),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(
                height: 48,
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Add Tracks',
                        style: TextStyle(
                          fontFamily: kPoppins,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 28),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _q,
                onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
                style: const TextStyle(
                    fontFamily: kPoppins, fontSize: 17, color: Colors.white),
                cursorColor: kChipOrange,
                decoration: InputDecoration(
                  hintText: 'Search tracks…',
                  hintStyle: const TextStyle(
                      fontFamily: kPoppins,
                      fontSize: 17,
                      color: Color(0xFF8E8E93)),
                  prefixIcon: const Icon(Icons.search, color: Color(0xFF8E8E93)),
                  contentPadding: const EdgeInsets.symmetric(vertical: 16),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFF5A5A5E)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: kChipOrange),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Expanded(
              child: visible.isEmpty
                  ? const Center(
                      child: Text('No tracks',
                          style: TextStyle(
                              fontFamily: kPoppins, color: Color(0xFF8E8E93))),
                    )
                  : ListView.builder(
                      padding: EdgeInsets.only(bottom: mq.padding.bottom + 16),
                      itemExtent: 60,
                      itemCount: visible.length,
                      itemBuilder: (c, i) {
                        final r = visible[i];
                        return _PickRow(
                          key: ValueKey(r.track.id),
                          r: r,
                          added: widget.playlist.trackIds.contains(r.track.id),
                          onTap: () => _toggle(r),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PickRow extends StatefulWidget {
  const _PickRow({
    super.key,
    required this.r,
    required this.added,
    required this.onTap,
  });

  final TrackRef r;
  final bool added;
  final VoidCallback onTap;

  @override
  State<_PickRow> createState() => _PickRowState();
}

class _PickRowState extends State<_PickRow> {
  @override
  void initState() {
    super.initState();
    final t = widget.r.track;
    if (t.durationMs == null) {
      context.read<LibraryStore>().ensureAudioDuration(t).then((_) {
        if (mounted) setState(() {});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.r;
    final ms = r.track.durationMs ?? 0;
    return InkWell(
      onTap: widget.onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(3),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CoverImage(path: r.album.coverPath, cacheWidth: 60),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    r.track.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontFamily: kPoppins,
                        fontSize: 16.5,
                        height: 1.25,
                        color: Colors.white),
                  ),
                  Text(
                    r.album.artist,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontFamily: kPoppins,
                        fontSize: 12.5,
                        height: 1.25,
                        color: Color(0xFF9A9A9E)),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            if (widget.added) ...[
              const Icon(Icons.check_circle, size: 20, color: kChipOrange),
              const SizedBox(width: 8),
            ],
            Text(
              ms > 0 ? fmtDuration(Duration(milliseconds: ms)) : '',
              style: const TextStyle(
                  fontFamily: kPoppins, fontSize: 13, color: Color(0xFF9A9A9E)),
            ),
          ],
        ),
      ),
    );
  }
}
