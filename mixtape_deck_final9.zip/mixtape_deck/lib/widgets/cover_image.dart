import 'dart:io';

import 'package:flutter/material.dart';

class CoverImage extends StatelessWidget {
  const CoverImage({super.key, this.path, this.cacheWidth = 500});

  final String? path;
  final int cacheWidth;

  @override
  Widget build(BuildContext context) {
    final p = path;
    if (p != null && File(p).existsSync()) {
      return Image.file(
        File(p),
        fit: BoxFit.cover,
        cacheWidth: cacheWidth,
        gaplessPlayback: true,
        errorBuilder: (_, __, ___) => _fallback(),
      );
    }
    return _fallback();
  }

  Widget _fallback() =>
      Image.asset('assets/default_cover.jpg', fit: BoxFit.cover);
}
