import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// Builds a top-to-bottom grey -> black gradient as raw pixels with dithering
/// (tiny random noise), so there are no visible bands/lines between shades.
Uint8List makeDitheredGradient(List<int> args) {
  final w = args[0];
  final h = args[1];
  final out = Uint8List(w * h * 4);

  const top = <double>[41, 41, 43];
  const bottom = <double>[11, 11, 12];

  var seed = 0x2545F491; // xorshift32 random numbers
  var i = 0;
  for (var y = 0; y < h; y++) {
    final t = h <= 1 ? 0.0 : y / (h - 1);
    final r0 = top[0] + (bottom[0] - top[0]) * t;
    final g0 = top[1] + (bottom[1] - top[1]) * t;
    final b0 = top[2] + (bottom[2] - top[2]) * t;
    for (var x = 0; x < w; x++) {
      seed ^= (seed << 13) & 0xFFFFFFFF;
      seed ^= seed >> 17;
      seed ^= (seed << 5) & 0xFFFFFFFF;
      seed &= 0xFFFFFFFF;
      final n = (seed & 0xFFFF) / 65536.0;
      out[i++] = (r0 + n).floor();
      out[i++] = (g0 + n).floor();
      out[i++] = (b0 + n).floor();
      out[i++] = 255;
    }
  }
  return out;
}

/// Full-screen smooth gradient background with [child] on top.
class DitheredBackground extends StatefulWidget {
  const DitheredBackground({super.key, required this.child});

  final Widget child;

  @override
  State<DitheredBackground> createState() => _DitheredBackgroundState();
}

class _DitheredBackgroundState extends State<DitheredBackground> {
  ui.Image? _img;
  int _w = 0;
  int _h = 0;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _ensure();
  }

  Future<void> _ensure() async {
    final mq = MediaQuery.of(context);
    final w = (mq.size.width * mq.devicePixelRatio).round();
    final h = (mq.size.height * mq.devicePixelRatio).round();
    if (w <= 0 || h <= 0 || (w == _w && h == _h)) return;
    _w = w;
    _h = h;
    final bytes = await compute(makeDitheredGradient, <int>[w, h]);
    if (!mounted) return;
    ui.decodeImageFromPixels(bytes, w, h, ui.PixelFormat.rgba8888, (img) {
      if (!mounted) {
        img.dispose();
        return;
      }
      setState(() => _img = img);
    });
  }

  @override
  void dispose() {
    _img?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(
          child: _img == null
              // Shown for a split second while the smooth version is made.
              ? const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Color(0xFF292A2B), Color(0xFF0B0B0C)],
                    ),
                  ),
                )
              : RawImage(
                  image: _img,
                  fit: BoxFit.fill,
                  filterQuality: FilterQuality.none,
                ),
        ),
        widget.child,
      ],
    );
  }
}
