import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../library_store.dart';
import '../player_controller.dart';
import '../screens/now_playing_screen.dart';
import '../theme.dart';
import 'cover_image.dart';

Future<void> shuffleWholeLibrary(BuildContext context) async {
  final store = context.read<LibraryStore>();
  final pl = context.read<PlayerController>();
  final all = store.allAudio;
  if (all.isEmpty) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Eat a tape first')));
    return;
  }
  await pl.playQueue(all, Random().nextInt(all.length), shuffleOn: true);
}

/// Bottom bar: "Swipe to Shuffle" when idle, the mini-player when something is
/// playing (swipe left = next, right = previous, tap = Now Playing), plus a
/// square button on the right:
///  - [onPlus]: the "+" button. It spins into an "X" diamond while [fabOpen].
///  - [onDots]: a "..." button (used on playlist pages).
class BottomDeck extends StatefulWidget {
  const BottomDeck({
    super.key,
    this.fabOpen = false,
    this.onPlus,
    this.onDots,
    this.showProgress = false,
  });

  final bool fabOpen;
  final VoidCallback? onPlus;
  final VoidCallback? onDots;
  final bool showProgress;

  @override
  State<BottomDeck> createState() => _BottomDeckState();
}

class _BottomDeckState extends State<BottomDeck> {
  double _dx = 0;

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerController>();
    final r = pl.current;

    final body = Container(
      height: 60,
      padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
      decoration: BoxDecoration(
        color: kPill,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Transform.translate(
        offset: Offset(_dx.clamp(-120.0, 120.0).toDouble(), 0),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                width: 44,
                height: 44,
                child: CoverImage(path: r?.album.coverPath, cacheWidth: 140),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: r == null
                  ? const Text(
                      'Swipe to Shuffle',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w300),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          r.track.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w700),
                        ),
                        Text(
                          r.album.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: kRowMuted, fontSize: 12),
                        ),
                      ],
                    ),
            ),
            if (r != null)
              IconButton(
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
                onPressed: pl.toggle,
                icon: Icon(
                  pl.playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                  size: 34,
                  color: kOrange,
                ),
              ),
          ],
        ),
      ),
    );

    final pillBox = (widget.showProgress && r != null)
        ? ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                body,
                Positioned(
                  left: 16,
                  right: 16,
                  top: 0,
                  child: _DeckProgress(pl),
                ),
              ],
            ),
          )
        : body;

    final pill = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (r == null) {
          shuffleWholeLibrary(context);
        } else {
          openNowPlaying(context);
        }
      },
      onHorizontalDragUpdate: (d) => setState(() => _dx += d.delta.dx),
      onHorizontalDragEnd: (d) {
        final moved = _dx;
        final v = d.primaryVelocity ?? 0;
        setState(() => _dx = 0);
        final swiped = moved.abs() > 60 || v.abs() > 700;
        if (!swiped) return;
        if (r == null) {
          shuffleWholeLibrary(context);
        } else if (moved < 0 || v < 0) {
          pl.next();
        } else {
          pl.previous();
        }
      },
      child: pillBox,
    );

    Widget? trailing;
    if (widget.onPlus != null) {
      // Quick spin that lands as a diamond with an X (a "+" turned 225 degrees).
      trailing = GestureDetector(
        onTap: widget.onPlus,
        child: AnimatedRotation(
          turns: widget.fabOpen ? 0.625 : 0.0,
          duration: const Duration(milliseconds: 380),
          curve: Curves.easeOutBack,
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: kPill,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(Icons.add, size: 28),
          ),
        ),
      );
    } else if (widget.onDots != null) {
      trailing = GestureDetector(
        onTap: widget.onDots,
        child: Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: kPill,
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Icon(Icons.more_horiz, size: 28),
        ),
      );
    }

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        child: Row(
          children: [
            Expanded(child: pill),
            if (trailing != null) ...[
              const SizedBox(width: 8),
              trailing,
            ],
          ],
        ),
      ),
    );
  }
}

class _DeckProgress extends StatelessWidget {
  const _DeckProgress(this.pl);

  final PlayerController pl;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Duration>(
      stream: pl.positionStream,
      builder: (context, snap) {
        final total = pl.player.duration?.inMilliseconds ?? 0;
        final pos = snap.data?.inMilliseconds ?? 0;
        final f = total > 0 ? (pos / total).clamp(0.0, 1.0).toDouble() : 0.0;
        return LinearProgressIndicator(
          value: f,
          minHeight: 3,
          color: kChipOrange,
          backgroundColor: const Color(0xFF3A3A3C),
        );
      },
    );
  }
}
