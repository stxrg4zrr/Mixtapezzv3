import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import 'app_keys.dart';
import 'library_store.dart';
import 'player_controller.dart';
import 'screens/home_screen.dart';
import 'theme.dart';
import 'utils.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  // Lock-screen + quick-settings media controls.
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.mixtape.mixtape_deck.audio',
    androidNotificationChannelName: 'Mixtapezz playback',
    androidNotificationOngoing: true,
    androidNotificationIcon: 'drawable/ic_notification',
    notificationColor: const Color(0xFFFF5500),
  );

  await Hive.initFlutter();
  await prepareDefaultCover();
  final store = await LibraryStore.open();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<LibraryStore>.value(value: store),
        ChangeNotifierProvider<PlayerController>(create: (_) => PlayerController()),
      ],
      child: const TapeEaterApp(),
    ),
  );

  // Android 13+: without this the lock-screen / quick-settings player stays hidden.
  WidgetsBinding.instance.addPostFrameCallback((_) async {
    try {
      final st = await Permission.notification.status;
      if (!st.isGranted) await Permission.notification.request();
    } catch (_) {}
  });
}

class TapeEaterApp extends StatelessWidget {
  const TapeEaterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mixtapezz',
      scaffoldMessengerKey: messengerKey,
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const HomeScreen(),
    );
  }
}
