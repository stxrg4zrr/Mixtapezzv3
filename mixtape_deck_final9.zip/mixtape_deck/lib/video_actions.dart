import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';

import 'library_store.dart';
import 'models.dart';

bool _isSub(String path) {
  final e = p.extension(path).toLowerCase();
  return e == '.srt' || e == '.vtt';
}

/// Lets the user pick an .srt / .vtt file and stores it next to the video.
Future<void> addSubtitlesToVideo(BuildContext context, TrackRef r) async {
  final messenger = ScaffoldMessenger.of(context);
  void say(String m) {
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(SnackBar(content: Text(m)));
  }

  FilePickerResult? res;
  try {
    res = await FilePicker.platform.pickFiles(type: FileType.any);
  } catch (_) {
    res = null;
  }
  if (res == null || res.files.isEmpty) return;
  final src = res.files.first.path;
  if (src == null) return;
  if (!_isSub(src)) {
    say('Pick an .srt or .vtt subtitle file');
    return;
  }

  try {
    final dir = p.dirname(r.track.path);
    final base = p.basenameWithoutExtension(r.track.path);
    final b = base.toLowerCase();
    // Remove older subtitle files of this video so the new one is used.
    for (final f in Directory(dir).listSync().whereType<File>()) {
      if (!_isSub(f.path)) continue;
      final n = p.basenameWithoutExtension(f.path).toLowerCase();
      if (n == b || n.startsWith('$b.')) {
        try {
          f.deleteSync();
        } catch (_) {}
      }
    }
    await File(src).copy(p.join(dir, '$base${p.extension(src).toLowerCase()}'));
    try {
      await FilePicker.platform.clearTemporaryFiles();
    } catch (_) {}
    say('Subtitles added. Open the video and tap SUBTITLES.');
  } catch (_) {
    say('Could not add the subtitles');
  }
}

/// Asks for a new title and saves it.
Future<void> editVideoTitle(BuildContext context, TrackRef r) async {
  final store = context.read<LibraryStore>();
  final c = TextEditingController(text: r.track.title);
  final ok = await showDialog<bool>(
    context: context,
    builder: (d) => AlertDialog(
      title: const Text('Edit Title'),
      content: TextField(
        controller: c,
        autofocus: true,
        decoration: const InputDecoration(hintText: 'Title'),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(d, false),
            child: const Text('Cancel')),
        TextButton(
            onPressed: () => Navigator.pop(d, true), child: const Text('Save')),
      ],
    ),
  );
  if (ok == true) await store.renameTrack(r.track, c.text);
}
