#!/usr/bin/env bash
# Generates the Android platform folder and applies: manifest (background audio),
# adaptive icon, dark splash screen, packages.
set -e

# Make every plugin compile against a recent Android SDK.
mkdir -p ~/.gradle/init.d
cat > ~/.gradle/init.d/sdk.gradle <<'GRADLE'
allprojects {
  afterEvaluate { p ->
    def a = p.extensions.findByName('android')
    if (a != null) {
      a.compileSdk = 36
      try { a.lint.checkReleaseBuilds = false } catch (Throwable ignored) {}
      try { a.lint.abortOnError = false } catch (Throwable ignored) {}
    }
  }
}
GRADLE

if [ ! -d android ]; then
  flutter create --org com.mixtape --project-name mixtape_deck --platforms=android _gen
  cp -r _gen/android ./android
  rm -rf _gen
fi

cat > android/app/src/main/AndroidManifest.xml <<'XML'
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <application
        android:label="Mixtapezz"
        android:name="${applicationName}"
        android:icon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:taskAffinity=""
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
        <service
            android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService" />
            </intent-filter>
        </service>
        <receiver
            android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true"
            tools:ignore="Instantiatable">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
    <queries>
        <intent>
            <action android:name="android.intent.action.PROCESS_TEXT"/>
            <data android:mimeType="text/plain"/>
        </intent>
    </queries>
</manifest>
XML

find android/app/src/main -name 'MainActivity.*' -delete
mkdir -p android/app/src/main/kotlin/com/mixtape/mixtape_deck
cat > android/app/src/main/kotlin/com/mixtape/mixtape_deck/MainActivity.kt <<'KT'
package com.mixtape.mixtape_deck

import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : AudioServiceActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // Back button on the home screen: send the app to the background (music keeps playing).
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "mixtapezz/app")
            .setMethodCallHandler { call, result ->
                if (call.method == "moveToBack") {
                    moveTaskToBack(true)
                    result.success(null)
                } else {
                    result.notImplemented()
                }
            }
    }
}
KT

# Turn off Android's release "lint vital" check (it crashed the build; it is not needed for an APK).
for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ] && ! grep -q "checkReleaseBuilds" "$f"; then
    cat >> "$f" <<'LINT'

android {
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
LINT
  fi
done

# Lock screen / quick settings player: the release build used to strip the
# notification icon (it is only referenced by name), so Android refused to show
# the media notification. Turn the shrinkers off and keep the icon explicitly.
for f in android/app/build.gradle.kts; do
  if [ -f "$f" ] && ! grep -q "isShrinkResources" "$f"; then
    cat >> "$f" <<'SHRINK'

android {
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}
SHRINK
  fi
done
if [ -f android/app/build.gradle ] && ! grep -q "shrinkResources" android/app/build.gradle; then
  cat >> android/app/build.gradle <<'SHRINK'

android {
    buildTypes {
        release {
            minifyEnabled false
            shrinkResources false
        }
    }
}
SHRINK
fi
mkdir -p android/app/src/main/res/raw
cat > android/app/src/main/res/raw/keep.xml <<'KEEP'
<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:tools="http://schemas.android.com/tools"
    tools:keep="@drawable/ic_notification,@mipmap/ic_launcher*"
    tools:shrinkMode="lax" />
KEEP

# Small monochrome icon for the media notification (lock screen / quick settings).
mkdir -p android/app/src/main/res/drawable
cat > android/app/src/main/res/drawable/ic_notification.xml <<'ICON'
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
  <path
      android:fillColor="#FFFFFFFF"
      android:pathData="M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z"/>
</vector>
ICON

flutter pub get
dart run flutter_launcher_icons
dart run flutter_native_splash:create

echo ""
echo "Done. Now run:  flutter build apk --release"
